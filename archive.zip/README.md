Python Basic Notebook
